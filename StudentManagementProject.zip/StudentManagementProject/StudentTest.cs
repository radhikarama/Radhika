﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assissnments.StudentManagementProject
{
    class StudentTest
    {
        static int num,ind=0;
        static void display(List<StudentManagement> hs)
        {
            Console.WriteLine("StudID\t\tName\t\tStudy\t    Total\t    Percentage");
            Console.WriteLine("_______\t     _________\t       _______\t  __________\t   ___________\t");
            foreach (StudentManagement s in hs)
                Console.WriteLine(" " + s.studId + "\t\t" + s.studName + "\t\t  " + s.Class +"\t\t"+s.total+"\t\t"+s.avg);
        }
        static void Remove(List<StudentManagement> hs)
        {
            Console.WriteLine("Enter the Student id to delete the record");
            int id = int.Parse(Console.ReadLine());
            foreach (StudentManagement s in hs)
            {
                if (id == s.studId)
                {
                    hs.Remove(s);
                    num--;
                    return;
                }
            }           
        }
        static void GetParticularClassDetails(List<StudentManagement> h)
        {
            Console.WriteLine("ENTER ROLE THE PERSON WHO IS SEARCHING FOR THE RECORDS");
            string role = Console.ReadLine();

            if (role == "Principal" || role == "Teacher")
            {
                Console.WriteLine("Enter the Student study to search the record");
                int stud = int.Parse(Console.ReadLine());
                Console.WriteLine("StudID\t\tName\t\tStudy\t     Total\t    Percentage");
                foreach (StudentManagement s in h)
                {
                    if (stud == s.Class)
                    {
                        Console.WriteLine(s.studId + "\t\t" + s.studName + "\t\t" + s.Class+"\t\t" + s.total +"\t\t"+ s.avg);
                    }
                }
            }
            else
            {
                Console.WriteLine("ONLY PRINCIPAL AND TEACHER WILL BE ALLOWED TO SEARCH ====> OTHERS ARE NOT ALLOWED");
                return;
            }
        }
        static bool isrepeated(int[] unique, int num, int ind)
        {
            for (int j = 0; j < ind; j++)
            {
                if (num == unique[j])
                    return true;
            }
            return false;
        }
        static void OverallPercentage()
        {
            StudentManagement s1;
            int[] classarray = new int[num];
            foreach (StudentManagement s in hash)
            {
                for (int i = 1; i <= num; i++)
                    {
                
                    if (isrepeated(classarray, s.Class, ind) == false)
                    {
                        classarray[ind] = s.Class;
                        ind++;
                    }
                }
            }
            Console.WriteLine("CLASS-STANDARD \t\t  OVERALL PERCENTAGE");
            Console.WriteLine("-------------------------------------------");
            int count;
            float sumofavg, avg;
            
            for (int i = 0; i < ind; i++)
            {
                count = 0;
                sumofavg = 0f;
                foreach (StudentManagement s in hash)
                {
                    for (int j = 0; j < num; j++)
                    {
                        if (classarray[i] == s.Class)
                        {
                            sumofavg += s.avg;
                            count++;
                        }
                    }
                }
                avg = sumofavg / count;
                
                Console.WriteLine("\t"+classarray[i]+"\t\t\t"+ avg);
            }
        }
        static void insertRecords()
        {
           float[] marks;
            float total, avg;
            Console.WriteLine("Enter Student Id name class");
            int id = int.Parse(Console.ReadLine());
            string name = Console.ReadLine();
            int stud = int.Parse(Console.ReadLine());
            Console.WriteLine("ENTER no of subjects");
            int n = int.Parse(Console.ReadLine());
            marks = new float[n];
            total = 0f;
            for(int i = 0; i < n; i++)
            {
                Console.WriteLine("Enter the subject name");
                string sub = Console.ReadLine();
                Console.Write("Enter the Subject:{0} marks  = ", i + 1);
                marks[i] = float.Parse(Console.ReadLine());
                total = total+marks[i];
            }
            avg = total / n;
            StudentManagement s = new StudentManagement(id, name, stud,marks,total,avg);
            num++;
            hash.Add(s);
        }
        static List<StudentManagement> hash;
        static void Main(string[] args)
        {
            bool flag = true;
            hash = new List<StudentManagement>();
            Console.WriteLine("1) INSERT STUDENT DETAILS");
            Console.WriteLine("2) REMOVE STUDENT RECORD");
            Console.WriteLine("3) DISPLAY STUDENT RECORDS");
            Console.WriteLine("4) GetParticularClassDetails SEARCH RECORDS");
            Console.WriteLine("5) OVERALL PERCENTAGE");
            Console.WriteLine("6) EXIT");

            while(true)
            {         
                Console.WriteLine("Enter your choice");
                int ch = int.Parse(Console.ReadLine());
                switch (ch)
                {
                    case 1:
                        insertRecords();
                        Console.WriteLine("Inserted");
                        break;
                    case 2:
                        Remove(hash);
                        Console.WriteLine("Deleted");
                        break;
                    case 3:
                        display(hash);
                        break;
                    case 4: GetParticularClassDetails(hash); break;
                    case 5:OverallPercentage();break;
                    case 6:
                       Environment.Exit(1); break;
                }
            }
            Console.ReadLine();
        }
    }
}
