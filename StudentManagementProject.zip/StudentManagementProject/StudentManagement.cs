﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assissnments.StudentManagementProject
{
    class StudentManagement
    {
        public int studId;
        public string studName;
        public int Class;
        public float[] marks;
        public float total, avg;
       /* public  StudentManagement(int sId,string name,int study)
        {
            this.studId = sId;
            studName = name;
            Class = study;
        }*/
        public StudentManagement(int sId, string name, int study , float[] marks,float total,float avg)
        {
            this.studId = sId;
            this.studName = name;
            this.Class = study;
            this.marks = marks;
           this. total = total;
            this.avg = avg;
        }
    }
}
