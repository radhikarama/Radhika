﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assissnments.EmployeeRecordsProject
{
    class EmployeeRecords
    {
        public int EmpId;
        public string EmpName;
        public int PhoneNo;
        public int DeptId;

        public EmployeeRecords()
        {
            Console.WriteLine("Enter the Employee Id");
            EmpId = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter the Employee Name");
            EmpName = Console.ReadLine();
            Console.WriteLine("Enter the Employee Phone Number");
            PhoneNo = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter the Employee Department Id");
            DeptId = int.Parse(Console.ReadLine());
        }
        public string  display()
        {
            return(EmpId.ToString().PadLeft(20) + " | " +EmpName.PadLeft(20)+"|"+
                PhoneNo.ToString().PadLeft(20)+"|"+DeptId.ToString().PadLeft(20));
        }
    }
}
