﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assissnments.EmployeeRecordsProject
{
    class ProjectDetails
    {
        public int ProjId;
        public string ProjName;
        public int EmpId;
        public int ManagerId;

        public ProjectDetails()
        {
            Console.WriteLine("Enter the Project Id");
            ProjId = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter the Project Name");
            ProjName = Console.ReadLine();
            Console.WriteLine("Enter the Employee Id");
            EmpId = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter the Manager Id");
            ManagerId = int.Parse(Console.ReadLine());
        }
        public string display()
        {
            return (ProjId.ToString().PadLeft(20) + " | " + ProjName.PadLeft(20) + "|" +EmpId.ToString().PadLeft(20)+"|"+
                ManagerId.ToString().PadLeft(20));
        }
    }
}
