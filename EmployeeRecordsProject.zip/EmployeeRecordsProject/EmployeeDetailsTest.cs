﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assissnments.EmployeeRecordsProject
{
    class EmployeeDetailsTest
    {
        static void Main(string[] args)
        {
            int ch;
            List<EmployeeRecords> employeeRecords = new List<EmployeeRecords>();
            List<DepartmentDetails> departRecords = new List<DepartmentDetails>();
            List<ProjectDetails> projectRecords = new List<ProjectDetails>();
             string filename= @"C:\Users\DELL\Desktop\EmployeeRecords.txt";
            string departfile = @"C:\Users\DELL\Desktop\DepartmentRecords.txt";
            string projectsfile = @"C:\Users\DELL\Desktop\ProjectsRecords.txt";
            DepartmentDetails dept = new DepartmentDetails();

            do
            {
                Console.WriteLine(" 1) Insert Employee Records ");
              //  Console.WriteLine(" 2) Writing Details into  );
                Console.WriteLine(" 2) Insert Department Details ");
                Console.WriteLine(" 3) Insert Project Details ");
                Console.WriteLine(" 4) Search all Employees who is under particular Department ");
                Console.WriteLine(" 5) Search all Projects by Employee Id ");
                Console.WriteLine(" 6) Exit ");
                ch = int.Parse(Console.ReadLine());
                switch (ch)
                {
                    case 1:EmployeeRecords emp = new EmployeeRecords();
                        employeeRecords.Add(emp);
                        try
                        {
                            using (StreamWriter writer = new StreamWriter(filename, true))
                            {
                                foreach (EmployeeRecords e in employeeRecords)
                                {

                                    writer.Write(e.display() + "\n");
                                }

                            }

                        }
                        catch (Exception ob)
                        {
                            Console.WriteLine(ob.Message);
                        }
                        break;
                    case 2:
                        dept.Department();
                        departRecords.Add(dept);
                        try
                        {
                            using (StreamWriter writer = new StreamWriter(departfile, true))
                            {
                                foreach (DepartmentDetails e in departRecords)
                                {

                                    writer.Write(e.display() + "\n");
                                }

                            }

                        }
                        catch (Exception ob)
                        {
                            Console.WriteLine(ob.Message);
                        }

                        break;
                    case 3:
                        ProjectDetails projects = new ProjectDetails();
                        projectRecords.Add(projects);
                        try
                        {
                            using (StreamWriter writer = new StreamWriter(projectsfile, true))
                            {
                                foreach (ProjectDetails e in projectRecords)
                                {

                                    writer.Write(e.display() + "\n");
                                }

                            }

                        }
                        catch (Exception ob)
                        {
                            Console.WriteLine(ob.Message);
                        }
                        break;
                    case 4:

                        Console.WriteLine("Enter the Department name");
                        string name = Console.ReadLine();
                        string[] departR=File.ReadAllLines(departfile);
                        string[] EmR;
                        EmR=File.ReadAllLines(filename);
                       //Console.ReadLine();
                        string line;
                        int found = 0;
                        for (int i = 0; i <departR.Length; i++)
                        {
                            if (departR[i].Contains(name))
                                Console.WriteLine(dept.DeptId);
                            found = 1;
                            // Console.WriteLine("ashdxsjdkh");

                            
                        }
                        if (found == 0)
                        {
                            Console.WriteLine("Not found");
                        }
                        if (found == 1)
                        {
                            //using (StreamReader reader = new StreamReader(departfile))
                            //{
                               
                                //while ((departR = reader.ReadLine()) != null)
                                   /* foreach (string e in departR)
                                    {
                                    Console.WriteLine(e);
                                            Console.WriteLine("SDfdvgfgf");
                                        // Console.WriteLine(e.DeptId);
                                        //writer.Write(e.DeptId);
                                    }*/
                              //  }
                            Console.WriteLine("Department Found====>" + name);

                        }




                        /* foreach (string item in departR)
                         {
                             foreach (string item2 in EmR)
                             {
                                 if (!item2.Equals(item))
                                 {
                                     Console.WriteLine(item2);
                                 }
                             }
                         }*/


                        break;
                    case 5:break;
                    case 6: Environment.Exit(1);
                        break;
                    default: Console.WriteLine("Invalid Choice");break;
                }
            } while (ch != 7);
            Console.ReadLine();
        }
    }
}
