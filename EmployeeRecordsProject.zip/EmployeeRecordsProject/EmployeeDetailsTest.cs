﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assissnments.EmployeeRecordsProject
{
    class EmployeeDetailsTest
    {
        static void Main(string[] args)
        {
            int ch;
             string filename= @"C:\Users\DELL\Desktop\EmployeeRecords.txt";
            string departfile = @"C:\Users\DELL\Desktop\DepartmentRecords.txt";
            string projectsfile = @"C:\Users\DELL\Desktop\ProjectsRecords.txt";

            do
            {
               
                Console.WriteLine(" 1) Inserting Employee Details into File");
               
                Console.WriteLine(" 2) Inserting Department Details into File");
               
                Console.WriteLine(" 3) Inserting Project Details into File");
                Console.WriteLine(" 4) Search all Employees who is under particular Department ");
                Console.WriteLine(" 5) Search all Projects by Employee Id ");
                Console.WriteLine(" 6) Exit ");
                ch = int.Parse(Console.ReadLine());
                switch (ch)
                {
                   
                    case 1:
                        EmployeeRecords emp1 = new EmployeeRecords();
                        try
                        {
                            using (StreamWriter writer = new StreamWriter(filename, true))
                            {
                              
                                    writer.Write(emp1);
                               
                            }
                           
                        }
                        catch (Exception ob)
                        {
                            Console.WriteLine(ob.Message);
                        }
                        break;
                  
                    case 2:
                        DepartmentDetails dept = new DepartmentDetails();
                        try
                        {
                            using (StreamWriter writer = new StreamWriter(departfile, true))
                            {
                               
                                    Console.WriteLine("sfreg");
                                    writer.Write(dept + "\n");
                                  }
                        }
                        catch (Exception ob)
                        {
                            Console.WriteLine(ob.Message);
                        }

                        break;
                  
                    case 3:
                        ProjectDetails projects1= new ProjectDetails();
                        try
                        {
                            using (StreamWriter writer = new StreamWriter(projectsfile,true))
                            {
                              
                                    writer.Write(projects1.ToString()+ "\n");
                              
                            }

                        }
                        catch (Exception ob)
                        {
                            Console.WriteLine(ob.Message);
                        }
                        break;
                    case 4:

                        Console.WriteLine("Enter the Department name");
                        string name = Console.ReadLine();
                       
                        try
                        {
                            string line,id="",line1;
                            using (StreamReader reader = new StreamReader(departfile))
                            {
                                using (StreamReader reader1 = new StreamReader(filename))
                                {

                                    while ((line = reader.ReadLine()) != null)
                                    {
                                        if (line.Contains(name))
                                        {
                                            var f = line.First(x => line.Contains(name));
                                            if (f != null)
                                            {                                               
                                                id = line.Substring(0, 20);                                               
                                                Console.WriteLine(id);
                                            }
                                        }
                                    }

                                    while ((line1 = reader1.ReadLine()) != null)
                                    {                                 
                                        if (line1.Contains(id))
                                        {
                                            Console.WriteLine(line1);
                                        }
                                    }
                                        }
                                    }
                                
                            }                   
                        catch (Exception ob)
                        {
                            Console.WriteLine(ob.Message);
                        }

                        break;
                    case 5:
                        Console.WriteLine("Enter the Manager Id");
                        int manager = int.Parse(Console.ReadLine());
                        try
                        {
                            string line,id="",line1;
                             string[] ids= new string[100];

                            using (StreamReader reader = new StreamReader(projectsfile))
                            {
                                using (StreamReader reader1 = new StreamReader(filename))
                                {
                                    while ((line = reader.ReadLine()) != null)
                                    {
                                        if (line.Contains(manager.ToString()))
                                        {
                                            var f = line.First(x => line.Contains(manager.ToString()));                                       
                                            if (f != null)
                                            {                                                                             
                                                    id = line.Substring(60,20);                                                 
                                                    Console.WriteLine(id);                                                     
                                            }
                                        }
                                    }                              
                                    Console.WriteLine(ids);
                                    while ((line1 = reader1.ReadLine()) != null)
                                    {                                      
                                        for (int i = 0; i < line1.Length; i++)
                                        {
                                            if (line1.Contains(ids[i]))
                                            {

                                                Console.WriteLine(line1);
                                           }                                         
                                            }
                                        }
                                    }
                                }
                            
                        }catch(Exception e)
                        {
                            Console.WriteLine(e.Message);
                        }
                                break;
                    case 6: Environment.Exit(1);
                        break;
                    default: Console.WriteLine("Invalid Choice");break;
                }
            } while (ch != 6);
            Console.ReadLine();
        }
    }
}
